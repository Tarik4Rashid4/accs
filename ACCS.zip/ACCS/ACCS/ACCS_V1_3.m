function [output] = ACCS_V1_3(m,c) 

for n=1:m

% Parameters of ACCS
Function_name = c; % Name of the test function that can be from F1 to F23 (Table 1,2,3 in the paper)
[lb,ub,dim,fobj]= Get_Functions_details(Function_name);

nVar = dim;            % Number of Decision Varibales

VarSize = [1 nVar];    % Matrix Size of Decision Variables

VarMin =  lb;          % Lower Bound of Decision Variables (Minimum time taken for each heart beat)
VarMax =  ub;          % Upper Bound of Decision Variables (Maximum time taken for each heart beat)

MaxIt = 500;           % Maximum Number of Iteration

nPop = 30;             % Population Size

heart_p = 0.985;       % Heart Power fixed factor

heartdamp = 0.999;     % Damping Coefficient of Heart Power

counter1 = 0;
counter2 = 0;
counter4 = 0;
counter3 = 0;
counter6 = 0;
counter5 = 0;
counter7 = 0;
counter8 = 0;

%% Initialization 
% The Heart Beat Template
empty_beats = [];
empty_beats.heartrate = [];
empty_beats.heartPower = [];
empty_beats.Best.heartrate = [];
empty_beats.Best.Cost = [];

% Create Population Array
beats = repmat(empty_beats, nPop, 1);

% Initialize Global Best
GlobalBest.Cost = inf;

% Initialize Population Members
for i=1:nPop
    
    % Generate Random Solution
    beats(i).heartrate = unifrnd(VarMin, VarMax,VarSize);   
    
    % Evalate Random Solution (Finding Fitness value using fitness function)
    beats(i).Cost = fobj(beats(i).heartrate);
    
    % Update the Personal Best
    beats(i).Best.heartrate = beats(i).heartrate;
    beats(i).Best.Cost = beats(i).Cost;
    
    % Update Global Best
    if beats(i).Best.Cost < GlobalBest.Cost
        GlobalBest = beats(i).Best;
    end
end

% Array to Hold Best Cost Value on Each Iteration (best Solution in each it
BestCosts = zeros(MaxIt, 1);

%% Main Loop of ACCS

for it=1:MaxIt

    for i=1:nPop        
     
      % Updating Heart rate at all nodes using calculation, which is based on ECG function (60/time)!)
      Var_impulseSA = (VarMin/VarMax)*rand();
      Var_impulAV = (VarMin/VarMax)*rand();
      Var_impulBoh = (VarMin/VarMax)*rand();
      Var_impulpf =  (VarMin/VarMax)*rand();
      
      R_SA = randi([1 nVar]);  % Random value among decision variables for SA node
      R_AV = randi([1 nVar]);  % Random value among decision variables for AV node
      R_BoH = randi([1 nVar]); % Random value among decision variables for BOH node
      R_PF = randi([1 nVar]);  % Random value among decision variables for PF node
      
      T=randi([0,10])/10; % Random Variable to self check rate at SA node
      
      
        % Update impulse at SA node
        if (beats(i).heartrate (R_SA) < Var_impulseSA || T <= 0.5)
           
           SA_rate=randi([5,10])/10; % Determine that heart rate at SA is in normal range    
          
           beats(i).heartrate = rand(VarSize).*(beats(i).heartrate - rand*GlobalBest.heartrate) - beats(i).heartrate;
           
           counter1 = counter1+1;
       
        else
            
            SA_rate=randi([0,5])/10; % Determine that heart rate at SA is not in normal range
        
            beats(i).heartrate= rand(VarSize).*(beats(i).heartrate - rand*GlobalBest.heartrate) - heart_p.*beats(i).heartrate;
            
            counter2 = counter2+1;   
        end
  
        % Update T_AV
        if (beats(i).heartrate(R_AV) < Var_impulAV || SA_rate <=0.5)
            
           AV_rate = randi([5,10])/10; % Determine that heart rate at AV is in normal range    
           
           Delay = randi([1,2])/10;
           
           beats(i).heartrate = rand(VarSize).*(beats(i).heartrate - rand*GlobalBest.heartrate) - Delay.*beats(i).heartrate;    
           
           counter3 = counter3+1;
        
        else 
            
            AV_rate = randi([0,5])/10; % Determine that heart rate at AV is not in normal range
            
            Delay = randi([2,3])/10;
            
            beats(i).heartrate= rand(VarSize).*(beats(i).heartrate - rand*GlobalBest.heartrate) - Delay.*heart_p.*beats(i).heartrate;
            
            counter4 = counter4+1;
        end
        
        % Update T_BoH
        if (beats(i).heartrate(R_BoH) < Var_impulBoh|| AV_rate <=0.5)
            
             Boh_rate=randi([5,10])/10; % Determine that heart rate at BoH is in normal range    
          
             beats(i).heartrate = rand(VarSize).*(rand*GlobalBest.heartrate + beats(i).heartrate) - beats(i).heartrate;     
            
             counter5 = counter5+1;
        else 
            
            Boh_rate=randi([0,5])/10;% Determine that heart rate at BoH is not in normal range
        
            beats(i).heartrate= rand(VarSize).*(beats(i).heartrate - rand*GlobalBest.heartrate) - heart_p.*beats(i).heartrate;
      
            counter6 = counter6+1;
        end

        % Update T_PF
        if (beats(i).heartrate(R_PF) < Var_impulpf || Boh_rate <=0.5)
            
            PF_rate=randi([5,10])/10; % Determine that heart rate at PF is in normal range    
          
            beats(i).heartrate = rand(VarSize).*(beats(i).heartrate - rand*GlobalBest.heartrate) - beats(i).heartrate;
            
            counter7 = counter7+1;
        else 
            
            PF_rate=randi([0,5])/10;% Determine that heart rate at PF is not in normal range
        
            beats(i).heartrate= rand(VarSize).*(beats(i).heartrate - rand*GlobalBest.heartrate) - heart_p.*beats(i).heartrate;
            
            counter8 = counter8+1;
        end        
    
        % Evaluation
        beats(i).Cost = fobj(beats(i).heartrate);
        
        % Update Personal Best
        if beats(i).Cost < beats(i).Best.Cost

            beats(i).Best.heartrate = beats(i).heartrate;

            beats(i).Best.Cost = beats(i).Cost;

            % Update Global Best
            if beats(i).Best.Cost < GlobalBest.Cost
                GlobalBest = beats(i).Best;
            end
        end
    end
    
    % Store the Best Cost Value
    BestCosts(it) = GlobalBest.Cost;
    
    % Display Iteration Information
    disp(['Iteration ' num2str(it) ': Best Cost = ' num2str(BestCosts(it))]);
    
     % Damping Heart Power
     heart_p = heart_p.*heartdamp;
end

   output = zeros(m, 1);
    
   output1 (n) = GlobalBest.Cost; % array to hold best cost value for each iteration
    
    output = output1;

end
end