%{  
     

    Rashid, T.A., Ahmed, A.M., Hassan, B.A., Yaseen, Z.M., Mirjalili, S., Bacanin, N., & Salih, S.Q. (Eds.). (2025).  
    Multi-objective Optimization Techniques: Variants, Hybrids, Improvements, and Applications (1st ed.).  
    CRC Press. https://doi.org/10.1201/9781003601555  

    Rebaz Mohammed, Nawzad K. Al-Salihi, Tarik A. Rashid, Aso M. Aladdin, Mokhtar Mohammadi, Jafar Majidpour. (2025)  
    Artificial Cardiac Conduction System Simulating Heart Function for Advanced Computational Problem Solving.  
    Multi-objective Optimization Techniques. CRC Press.  
    DOI: https://www.taylorfrancis.com/chapters/edit/10.1201/9781003601555-16/  
%}  

%% Call Function

[output] = ACCS_V1_3(1, 'F1');

average = mean(output);

std_dev = std(output);

disp(['Average of Best Cost = ' num2str(average)]);

disp(['Standard Deviation of Best Cost = ' num2str(std_dev)]);